import React from "react";

const Modal = () => {
  return (
    <div>
      <h1>this is the modal</h1>
    </div>
  );
};

export default Modal;
