import React, { Component } from "react";
import Modal from "./Modal";

class DeleteRegister extends Component {
  render() {
    return (
      <div>
        <Modal />
      </div>
    );
  }
}

export default DeleteRegister;
